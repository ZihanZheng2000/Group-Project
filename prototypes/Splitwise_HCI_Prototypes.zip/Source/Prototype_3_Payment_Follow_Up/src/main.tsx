import { useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { balance, contacts, groupIds, groupName, groups, money, people, type Entry, type Person, type Group } from './ledger'
import { Avatar, Icon } from './ui'
import { ExpenseForm, Modal, PaymentForm } from './forms'
import { addEvent, deliverReminder, outstanding, seedDemo, setReminder, type Demo } from './followup'
import { Conversation } from './conversation'
import './style.css'

const storageKey = 'cs6750-splitwise-alternative-3-v1'
const pages = {
  dashboard: { name: 'Dashboard', icon: 'dashboard' },
  expenses: { name: 'All expenses', icon: 'receipt' },
  balances: { name: 'Balances', icon: 'balances' },
  payments: { name: 'Payment history', icon: 'clock' },
}
type Page = keyof typeof pages
type Route = { page: Page } | { page: 'group'; id: keyof typeof groups } | { page: 'friend'; id: Person }
type Overlay = 'expense' | 'payment' | 'reset' | null

function loadDemo(): Demo {
  try {
    const stored = localStorage.getItem(storageKey)
    if (stored) return JSON.parse(stored)
  } catch { /* Allow the demo to run without browser storage. */ }
  return seedDemo
}

function Activity({ actor, entries, onSelect }: { actor: Person; entries: Entry[]; onSelect: (entry: Entry) => void }) {
  if (!entries.length) return <div className="empty"><Icon name="receipt" size={24}/><p>No activity to show here yet.</p></div>
  return <ul className="activity">{entries.map(entry => {
    const payment = entry.kind === 'payment'
    const payer = payment ? entry.from : entry.payer
    const title = payment ? `${payer === actor ? 'You' : people[payer].name} paid ${entry.to === actor ? 'you' : people[entry.to].name}` : entry.title
    const date = new Date(entry.date + 'T12:00:00')
    return <li key={entry.id}><button className="activity-row" onClick={() => onSelect(entry)}>
      <span className="row-date"><span>{date.toLocaleDateString('en-US', { month: 'short' })}</span><strong>{date.getDate()}</strong></span>
      <span className={`entry-icon ${payment ? 'payment-icon' : ''}`}><Icon name={payment ? 'exchange' : 'receipt'}/></span>
      <span className="row-title"><strong>{title}</strong><span>{groupName(entry.group)}</span></span>
      <span className="row-amount"><strong>{money(entry.amount)}</strong><span>{payment ? 'Payment' : payer === actor ? 'You paid' : `${people[payer].name.split(' ')[0]} paid`}</span></span>
      <Icon name="chevron" size={15}/>
    </button></li>
  })}</ul>
}

function App() {
  const [demo, setDemo] = useState(loadDemo)
  const { entries } = demo
  const [role, setRole] = useState<'me' | 'sam'>('sam')
  const [followOpen, setFollowOpen] = useState(false)
  function openFollowup() {
    setFollowOpen(true)
  }
  const [route, setRoute] = useState<Route>({ page: 'dashboard' })
  const [overlay, setOverlay] = useState<Overlay>(null)
  const [detail, setDetail] = useState<Entry | null>(null)
  const [notice, setNotice] = useState('')
  useEffect(() => {
    try { localStorage.setItem(storageKey, JSON.stringify(demo)) } catch { /* Storage may be disabled. */ }
  }, [demo])
  useEffect(() => {
    if (demo.reminderAt === undefined) return
    if (outstanding(demo.entries) === 0) {
      setDemo(current => setReminder(current, 'sam'))
      return
    }
    // Recheck after tab suspension and avoid overflowing the browser timer.
    const deliver = () => setDemo(deliverReminder)
    const timer = window.setTimeout(deliver, Math.min(2_147_483_647, Math.max(0, demo.reminderAt - Date.now())))
    window.addEventListener('focus', deliver)
    // Poll as a fallback for very long schedules.
    const polling = window.setInterval(deliver, 60_000)
    return () => {
      window.clearTimeout(timer)
      window.clearInterval(polling)
      window.removeEventListener('focus', deliver)
    }
  }, [demo])
  useEffect(() => {
    if (!notice) return
    const timeout = window.setTimeout(() => setNotice(''), 4000)
    return () => window.clearTimeout(timeout)
  }, [notice])
  const group = route.page === 'group' ? route.id : undefined
  const friend = route.page === 'friend' ? route.id : undefined
  const title = route.page === 'group' ? groupName(route.id) : route.page === 'friend' ? people[route.id].name : pages[route.page].name
  const scoped = group ? entries.filter(entry => entry.group === group) : entries
  const rows = contacts(role).filter(id => (!friend || friend === id) && (!group || groups[group].members.includes(id)))
    .map(id => ({ id, cents: balance(scoped, role, id) }))
  const owed = rows.reduce((total, row) => total + Math.max(0, row.cents), 0)
  const owe = rows.reduce((total, row) => total + Math.max(0, -row.cents), 0)
  const visible = scoped.filter(entry => {
    const involvesRole = entry.kind === 'payment'
      ? entry.from === role || entry.to === role
      : entry.payer === role || entry.shares.some(share => share.person === role)
    if (role === 'sam' && !involvesRole && !(entry.group !== 'personal' && groups[entry.group].members.includes(role))) return false
    if (route.page === 'expenses') return entry.kind === 'expense'
    if (route.page === 'payments') return entry.kind === 'payment'
    if (!friend) return true
    return entry.kind === 'payment'
      ? [entry.from, entry.to].includes(friend) && [entry.from, entry.to].includes(role)
      : (entry.payer === role && entry.shares.some(share => share.person === friend)) ||
        (entry.payer === friend && entry.shares.some(share => share.person === role))
  }).sort((a, b) => b.date.localeCompare(a.date))
  const close = () => setOverlay(null)
  function save(newEntries: Entry[], message: string) {
    setDemo(current => ({ ...current, entries: [...newEntries, ...current.entries] }))
    close()
    setNotice(message)
  }
  function navigate(next: Route) {
    setFollowOpen(false)
    setRoute(next)
    setNotice('')
  }

  function switchRole(next: 'me' | 'sam') {
    if (next === role) return
    setRole(next)
    setNotice('')
    setDetail(null)
    if (friend === next || (group && !groups[group].members.includes(next))) {
      setRoute({ page: 'dashboard' })
    }
  }

  return <>
    <header className="topbar"><div className="top-inner">
      <button className="brand" onClick={() => navigate({ page: 'dashboard' })}><span className="brand-icon"><Icon name="logo" size={22}/></span> Shared Ledger</button>
      <div className="profile"><span>CS 6750 · Prototype 3</span><label className="role-picker">View as<select value={role} onChange={event => switchRole(event.target.value as 'me' | 'sam')}><option value="me">Alex Kim</option><option value="sam">Sam Patel</option></select></label></div>
    </div></header>
    <div className="shell">
      <aside className="sidebar"><nav aria-label="Main navigation">
        <div className="nav-label">Overview</div>
        {(Object.keys(pages) as Page[]).map(page => <button key={page} className="nav-item" aria-current={route.page === page ? 'page' : undefined} onClick={() => navigate({ page })}><Icon name={pages[page].icon}/>{pages[page].name}</button>)}
        <div className="nav-label">Groups</div>
        {groupIds.filter(id => groups[id].members.includes(role)).map(id => <button key={id} className="nav-item" aria-current={group === id ? 'page' : undefined} onClick={() => navigate({ page: 'group', id })}><Icon name={groups[id].icon}/>{groupName(id)}</button>)}
        <div className="nav-label">Friends</div>
        {contacts(role).map(id => <button key={id} className="nav-item" aria-current={friend === id ? 'page' : undefined} onClick={() => navigate({ page: 'friend', id })}><Avatar person={id}/>{people[id].name}</button>)}
      </nav><div className="sidebar-footer"><button className="nav-item" onClick={() => setOverlay('reset')}><Icon name="reset"/>Reset demo</button></div></aside>
      <main>
        {followOpen ? <Conversation key={role} demo={demo} role={role} switchRole={switchRole}
          schedule={at => setDemo(current => setReminder(current, role, at))}
          send={event => setDemo(current => addEvent(current, role, event))}
          back={() => navigate({ page: 'group', id: 'trip' })}
          history={() => navigate({ page: 'payments' })}
        /> : <>
        <div className="page-heading"><div><h1>{title}</h1><p className="muted">{group ? groups[group].members.map(id => id === role ? 'You' : people[id].name).join(', ') : friend ? 'Shared expenses and payments' : { dashboard: 'Your shared expenses and outstanding balances.', expenses: 'Browse expenses across your groups and friends.', balances: 'See who owes you and who you owe.', payments: 'Review your recorded payments.' }[route.page as Page]}</p></div>
          <div className="page-actions"><button className="button secondary" onClick={() => setOverlay('payment')}><Icon name="exchange"/>Settle up</button><button className="button primary" onClick={() => setOverlay('expense')}><Icon name="plus"/>Add expense</button></div>
        </div>
        {(route.page === 'dashboard' || group === 'trip' || friend === (role === 'sam' ? 'me' : 'sam')) && <section className="panel follow-entry">
          <div><h2>Chicago Weekend</h2><p className="small muted">Payment follow-up with Alex and Sam</p></div>
          <button className="button secondary" onClick={openFollowup}>Open payment follow-up <Icon name="arrow" size={16}/></button>
        </section>}
        {route.page !== 'expenses' && route.page !== 'payments' && <div className="summary-grid">
          <div className="summary"><span>Total balance</span><strong className={owed >= owe ? 'positive' : 'negative'}>{money(owed - owe)}</strong></div>
          <div className="summary"><span>You owe</span><strong className="negative">{money(owe)}</strong></div>
          <div className="summary"><span>You are owed</span><strong className="positive">{money(owed)}</strong></div>
        </div>}
        {(route.page === 'dashboard' || route.page === 'group' || route.page === 'balances') && <section className="panel">
          <header className="panel-heading"><h2>{group ? 'Your group balances' : 'Your balances'}</h2>{route.page === 'dashboard' && <button className="text-action" onClick={() => navigate({ page: 'balances' })}>View balances <Icon name="arrow" size={16}/></button>}</header>
          <div className="balance-grid">
            {([{ label: 'You owe', direction: -1 }, { label: 'You are owed', direction: 1 }]).map(({ label, direction }) => <div key={label} className="balance-column">
              <h3>{label}</h3>
              {rows.filter(row => Math.sign(row.cents) === direction).length === 0 && <p className="muted small">All settled on this side.</p>}
              {rows.filter(row => Math.sign(row.cents) === direction).map(({ id, cents }) => <button className="balance-row" key={id} onClick={() => navigate({ page: 'friend', id })}><Avatar person={id}/><span>{people[id].name}</span><strong className={direction < 0 ? 'negative' : 'positive'}>{money(Math.abs(cents))}</strong><Icon name="chevron" size={14}/></button>)}
            </div>)}
          </div>
        </section>}
        {route.page !== 'balances' && <section className="panel">
          <header className="panel-heading"><h2>{route.page === 'payments' ? 'Recorded payments' : route.page === 'expenses' ? 'Expense list' : 'Recent activity'}</h2>{route.page === 'dashboard' && <button className="text-action" onClick={() => navigate({ page: 'expenses' })}>All expenses <Icon name="arrow" size={16}/></button>}</header>
          <Activity actor={role} entries={route.page === 'dashboard' ? visible.slice(0, 5) : visible} onSelect={setDetail}/>
        </section>}
        </>}
      </main>
    </div>
    <div className="toast-host" role="status">{notice && <div className="toast"><Icon name="check"/>{notice}</div>}</div>
    {overlay === 'expense' && <Modal title="Add an expense" close={close}><ExpenseForm actor={role} group={group} friend={friend} save={save} close={close}/></Modal>}
    {overlay === 'payment' && <Modal title="Settle up" close={close}><PaymentForm actor={role} entries={entries} group={group} friend={friend} save={save} close={close}/></Modal>}
    {overlay === 'reset' && <Modal title="Reset demo?" close={close}><div className="form"><p>This restores the starting balances and removes the conversation and all expenses and payments added during this session.</p><footer className="modal-actions"><button className="button secondary" onClick={close}>Cancel</button><button className="button primary" onClick={() => { setDemo(seedDemo); setRole('sam'); navigate({ page: 'dashboard' }); close(); setNotice('Demo reset.') }}>Reset demo</button></footer></div></Modal>}
    {detail && <Modal title={detail.kind === 'expense' ? detail.title : 'Payment details'} close={() => setDetail(null)}><div className="form">
      <div className="detail-total">{money(detail.amount)}</div><p className="muted">{groupName(detail.group)} · {detail.date}</p>
      {detail.kind === 'expense' ? <><p>Paid by {people[detail.payer].name}</p><ul className="detail-shares">{detail.shares.map(share => <li key={share.person}>{people[share.person].name}<strong>{money(share.cents)}</strong></li>)}</ul></> : <p>{people[detail.from].name} paid {people[detail.to].name}. Simulated payment.</p>}
    </div></Modal>}
  </>
}
createRoot(document.getElementById('root')!).render(<App/>)
