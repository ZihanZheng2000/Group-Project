import { dinnerCreator, dinnerId, initialEntries, split, today, type Entry, type Expense, type Person } from './ledger'

export type Role = 'me' | 'sam'
type Status = 'pending' | 'approved' | 'rejected'
export type Request = {
  id: string
  date: string
  reason: string
  before: Expense['shares']
  after: Expense['shares']
  status: Status
}
export type Demo = { entries: Entry[]; requests: Request[] }
export const seedDemo: Demo = { entries: initialEntries, requests: [] }
export function getDinner(entries: Entry[]) {
  return entries.find((entry): entry is Expense => entry.id === dinnerId && entry.kind === 'expense')!
}
export function dinnerPayment(entries: Entry[], person: Person) {
  return entries.reduce((sum, entry) => sum + (
    entry.kind === 'payment' && entry.expenseId === dinnerId && entry.from === person && entry.to === dinnerCreator ? entry.amount : 0
  ), 0)
}
export function propose(dinner: Expense) {
  return split(dinner.amount, dinner.shares.filter(share => share.person !== 'jordan').map(share => share.person))
}
export function submitRequest(demo: Demo, role: Role, reason: string, id: string): Demo {
  const dinner = getDinner(demo.entries)
  const trimmed = reason.trim()
  if (role !== 'me' || !trimmed || demo.requests.some(request => request.status === 'pending') || !dinner.shares.some(share => share.person === 'jordan')) return demo
  return { ...demo, requests: [{ id, date: today(), reason: trimmed, before: dinner.shares, after: propose(dinner), status: 'pending' }, ...demo.requests] }
}
export function decideRequest(demo: Demo, role: Role, id: string, status: Exclude<Status, 'pending'>): Demo {
  if (role !== dinnerCreator || !demo.requests.some(request => request.id === id && request.status === 'pending')) return demo
  const request = demo.requests.find(item => item.id === id)!
  const entries = status === 'approved'
    ? demo.entries.map(entry => entry.id === dinnerId && entry.kind === 'expense' ? { ...entry, shares: request.after } : entry)
    : demo.entries
  return { entries, requests: demo.requests.map(item => item.id === id ? { ...item, status } : item) }
}
