import { useState, type FormEvent } from 'react'
import { balance, dinnerCreator, groupName, groups, money, people, type Entry, type Expense, type Person } from './ledger'
import { dinnerPayment, getDinner, propose, type Demo, type Request, type Role } from './requests'
import { Avatar, Icon } from './ui'

const shareOf = (shares: Expense['shares'], person: Person) => shares.find(share => share.person === person)?.cents ?? 0
const statusText = { pending: 'Pending review by Sam', approved: 'Approved by Sam', rejected: 'Rejected by Sam' }
const remaining = (amount: number, paid: number) => amount >= paid ? money(amount - paid) : `${money(paid - amount)} credit`

function ImpactTable({ entries, before, after }: { entries: Entry[]; before: Expense['shares']; after: Expense['shares'] }) {
  return <div className="table-scroll" tabIndex={0} role="region" aria-label="Dinner split comparison">
    <table className="impact-table">
      <caption>Dinner only</caption>
      <thead>
        <tr><th scope="col" rowSpan={2}>Member</th><th scope="colgroup" colSpan={2}>Before change</th><th scope="colgroup" colSpan={2}>After proposed change</th><th scope="col" rowSpan={2}>Already paid Sam</th></tr>
        <tr><th scope="col">Share</th><th scope="col">Still owes Sam</th><th scope="col">Share</th><th scope="col">Still owes Sam</th></tr>
      </thead>
      <tbody>{groups.trip.members.map(person => {
        const oldShare = shareOf(before, person)
        const newShare = shareOf(after, person)
        const paid = dinnerPayment(entries, person)
        return <tr key={person}><th scope="row">{people[person].name}</th><td>{money(oldShare)}</td><td>{person === dinnerCreator ? '—' : remaining(oldShare, paid)}</td>
          <td>{money(newShare)}</td><td className={person === 'maya' ? 'new-amount' : ''}>{person === dinnerCreator ? '—' : remaining(newShare, paid)}</td><td>{person === dinnerCreator ? '—' : money(paid)}</td></tr>
      })}</tbody>
    </table>
  </div>
}

export function DinnerReview({ demo, role, goBack, settle, submit, decide }: {
  demo: Demo; role: Role; goBack: () => void; settle: () => void
  submit: (reason: string) => void; decide: (id: string, status: 'approved' | 'rejected') => void
}) {
  const dinner = getDinner(demo.entries)
  const [editing, setEditing] = useState(false)
  const [reason, setReason] = useState('')
  const current = demo.requests[0]
  const pending = current?.status === 'pending'
  const alexNet = -balance(demo.entries.filter(entry => entry.group === 'trip'), 'me', 'sam')
  const mayaPaid = dinnerPayment(demo.entries, 'maya')
  const mayaRemaining = remaining(shareOf(dinner.shares, 'maya'), mayaPaid)
  const canRequest = role === 'me' && !pending && dinner.shares.some(share => share.person === 'jordan')
  function send(event: FormEvent) {
    event.preventDefault()
    if (!reason.trim()) return
    submit(reason)
    setEditing(false)
    setReason('')
  }

  return <>
    <button className="text-action mb-4" onClick={goBack}><span aria-hidden="true">←</span> Back to Chicago Weekend</button>
    <div className="page-heading"><div><h1>{dinner.title}</h1><p className="muted">{groupName(dinner.group)} · November 13, 2026</p></div>
      {role === 'me' && <button className="button secondary" onClick={settle}><Icon name="exchange"/>Settle up</button>}
    </div>
    <div className="summary-grid">
      <div className="summary"><span>Dinner total</span><strong>{money(dinner.amount)}</strong><span>Created and paid by Sam</span></div>
      <div className="summary"><span>Maya still owes for dinner</span><strong>{mayaRemaining}</strong><span>{money(mayaPaid)} already paid</span></div>
      <div className="summary"><span>Alex’s net with Sam</span><strong>{money(Math.abs(alexNet))}</strong><span>{alexNet < 0 ? 'Sam owes Alex' : alexNet > 0 ? 'Alex owes Sam' : 'Settled'} · Chicago Weekend</span></div>
    </div>
    {(editing || current) && <section className="panel">
      <header className="panel-heading"><h2>{editing ? 'Request a split change' : 'Split change request'}</h2>{!editing && current && <span className={`request-status ${current.status}`}>{statusText[current.status]}</span>}</header>
      {editing ? <form className="form" onSubmit={send}>
        <label className="choice-label">Change to the dinner split<select defaultValue="jordan"><option value="jordan">Remove Jordan Lee</option></select></label>
        <label>Reason<textarea autoFocus rows={2} maxLength={300} required placeholder="Explain why the split should change" value={reason} onChange={event => setReason(event.target.value)}/></label>
        <ImpactTable entries={demo.entries} before={dinner.shares} after={propose(dinner)}/>
        <footer className="modal-actions"><button type="button" className="button secondary" onClick={() => setEditing(false)}>Cancel</button><button className="button primary" disabled={!reason.trim()}>Submit request</button></footer>
      </form> : current && <div className="review-content">
        <div className="request-message"><Avatar person="me"/><div><strong>Alex requested to remove Jordan Lee</strong><p>{current.reason}</p></div></div>
        <ImpactTable entries={demo.entries} before={current.before} after={current.after}/>
        {pending && role === 'sam' && <div className="review-actions"><p className="muted small">Approval updates the shares and keeps the payments already recorded.</p><div><button className="button secondary" onClick={() => decide(current.id, 'rejected')}>Reject request</button><button className="button primary" onClick={() => decide(current.id, 'approved')}>Approve change</button></div></div>}
        {pending && role === 'me' && <p className="muted small">Your current balances stay in effect until Sam approves a change.</p>}
      </div>}
    </section>}
    <section className="panel">
      <header className="panel-heading"><h2>Current dinner split</h2>{canRequest && !editing && <button className="button primary" onClick={() => setEditing(true)}>Request change</button>}</header>
      <ul className="split-list">{groups.trip.members.map(person => <li key={person}><Avatar person={person}/><span>{people[person].name}</span><strong>{money(shareOf(dinner.shares, person))}</strong></li>)}</ul>
    </section>
    <section className="panel">
      <header className="panel-heading"><h2>Request history</h2></header>
      {demo.requests.length ? <ul className="request-history">{demo.requests.map(request => <li key={request.id}><details>
        <summary><strong>Remove Jordan Lee</strong><span className={`request-status ${request.status}`}>{statusText[request.status]}</span></summary>
        <p className="muted small">{request.date} · Requested by Alex Kim</p><p>{request.reason}</p>
        <ImpactTable entries={demo.entries} before={request.before} after={request.after}/>
      </details></li>)}</ul> : <p className="empty">No change requests yet.</p>}
    </section>
  </>
}
